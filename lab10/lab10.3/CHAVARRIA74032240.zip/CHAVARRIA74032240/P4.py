# P4.py
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Queue:
    def __init__(self):
        self.__head = None
        self.__last = None
        self.__size = 0

    def isEmpty(self):
        return self.__size == 0

    def enqueue(self, value):
        new_node = Node(value)
        if self.isEmpty():
            self.__head = new_node
        else:
            self.__last.next = new_node
        self.__last = new_node
        self.__size += 1

    def dequeue(self):
        if self.isEmpty():
            return None
        value = self.__head.data
        self.__head = self.__head.next
        self.__size -= 1
        if self.__size == 0:
            self.__last = None
        return value

    def getSize(self):
        return self.__size

    def showAll(self):
        current = self.__head
        while current:
            print(current.data)
            current = current.next

class PrintRequest:
    def __init__(self, machine_id, filename):
        self.machine_id = machine_id
        self.filename = filename

    def __str__(self):
        return f"{self.machine_id} -> {self.filename}"

class PrinterQueue:
    def __init__(self):
        self.queue = Queue()

    def addRequest(self, request):
        self.queue.enqueue(request)

    def printWork(self):
        """Simula impresión de la primera solicitud."""
        request = self.queue.dequeue()
        if request:
            print(f"Imprimiendo: {request}")
        else:
            print("No hay peticiones.")

    def getNumRequest(self):
        return self.queue.getSize()

    def showAll(self):
        print("Cola actual de peticiones:")
        self.queue.showAll()

    def printAll(self):
        while not self.queue.isEmpty():
            self.printWork()
