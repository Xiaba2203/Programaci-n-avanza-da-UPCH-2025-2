class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Queue:
    def __init__(self):
        self.__head = None
        self.__last = None
        self.__size = 0

    def isEmpty(self):
        return self.__size == 0

    def enqueue(self, value):
        new_node = Node(value)
        if self.isEmpty():
            self.__head = new_node
        else:
            self.__last.next = new_node
        self.__last = new_node
        self.__size += 1

    def dequeue(self):
        if self.isEmpty():
            return None
        value = self.__head.data
        self.__head = self.__head.next
        self.__size -= 1
        if self.__size == 0:
            self.__last = None
        return value

    def getSize(self):
        return self.__size
