class Stack:
    """Pila simple con lista."""
    def __init__(self):
        self.items = []

    def push(self, value):
        self.items.append(value)

    def pop(self):
        if not self.isEmpty():
            return self.items.pop()
        return None

    def isEmpty(self):
        return len(self.items) == 0

class QueueUsingStacks:
    """Cola implementada usando dos pilas."""
    def __init__(self):
        self.stack_in = Stack()
        self.stack_out = Stack()

    def enqueue(self, value):
        self.stack_in.push(value)

    def dequeue(self):
        if self.stack_out.isEmpty():
            while not self.stack_in.isEmpty():
                self.stack_out.push(self.stack_in.pop())
        return self.stack_out.pop()

    def isEmpty(self):
        return self.stack_in.isEmpty() and self.stack_out.isEmpty()

    def __str__(self):
        return f"Entrada: {self.stack_in.items}, Salida: {self.stack_out.items}"
