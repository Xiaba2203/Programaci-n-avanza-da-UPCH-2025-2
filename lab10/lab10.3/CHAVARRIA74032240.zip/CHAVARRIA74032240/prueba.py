from P1 import Queue as Queue1
from P2 import Queue as Queue2
from P3 import Queue as Queue3
from P4 import PrinterQueue, PrintRequest
from P5 import QueueUsingStacks

def test_queue1():
    print("== Test P1: Queue básica ==")
    q = Queue1()
    q.enqueue(10)
    q.enqueue(20)
    print("dequeue ->", q.dequeue())
    print("size ->", q.getSize())
    print()

def test_queue2():
    print("== Test P2: Queue con __str__ y __len__ ==")
    q = Queue2()
    q.enqueue("A")
    q.enqueue("B")
    print(q)
    print("len:", len(q))
    print("dequeue ->", q.dequeue())
    print(q)
    print()

def test_queue3():
    print("== Test P3: Queue sin last ==")
    q = Queue3()
    q.enqueue(1)
    q.enqueue(2)
    q.enqueue(3)
    print("antes:", q)
    print("dequeue ->", q.dequeue())
    print("después:", q)
    print()

def test_printer():
    print("== Test P4: PrinterQueue ==")
    printer = PrinterQueue()
    printer.addRequest(PrintRequest("PC_1", "file1.pdf"))
    printer.addRequest(PrintRequest("PC_2", "file2.docx"))
    printer.showAll()
    printer.printWork()
    printer.printAll()
    printer.printWork()  # Ya vacía
    print()

def test_stack_queue():
    print("== Test P5: QueueUsingStacks ==")
    q = QueueUsingStacks()
    q.enqueue("uno")
    q.enqueue("dos")
    print("dequeue ->", q.dequeue())
    q.enqueue("tres")
    print("dequeue ->", q.dequeue())
    print("dequeue ->", q.dequeue())
    print("isEmpty:", q.isEmpty())
    print()

if __name__ == "__main__":
    test_queue1()
    test_queue2()
    test_queue3()
    test_printer()
    test_stack_queue()
