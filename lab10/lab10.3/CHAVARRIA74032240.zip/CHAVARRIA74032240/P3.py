class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Queue:
    """Versión sin atributo last"""
    def __init__(self):
        self.__head = None
        self.__size = 0

    def isEmpty(self):
        return self.__head is None

    def enqueue(self, value):
        new_node = Node(value)
        if self.isEmpty():
            self.__head = new_node
        else:
            current = self.__head
            while current.next:   # recorre hasta el final
                current = current.next
            current.next = new_node
        self.__size += 1

    def dequeue(self):
        if self.isEmpty():
            return None
        value = self.__head.data
        self.__head = self.__head.next
        self.__size -= 1
        return value

    def getSize(self):
        return self.__size
