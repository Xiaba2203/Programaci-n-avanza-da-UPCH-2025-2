students = {"peter", "john"}
students.remove("johnson")   # ❌ ERROR: KeyError (johnson no está en el conjunto)
print(students)
