# Sí, pueden contener distintos tipos inmutables
lista = [1, "hola", 3.14, (1,2)]
conjunto = {1, "hola", 3.14, (1,2)}
tupla = (1, "hola", 3.14, (1,2))

print(lista)
print(conjunto)
print(tupla)
