numbers = {1, 4, 5, 6}

print(len(numbers))   # 4
print(max(numbers))   # 6
print(min(numbers))   # 1
print(sum(numbers))   # 16
