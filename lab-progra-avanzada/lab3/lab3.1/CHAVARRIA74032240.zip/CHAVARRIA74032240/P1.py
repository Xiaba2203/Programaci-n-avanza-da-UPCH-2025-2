# crea un conjunto vacío
conjunto_vacio = set()