t = (1, 2, 3, 7, 9, 0, 5)  # tupla ejemplo

print(max(t))  # imprime el mayor
print(min(t))  # imprime el menor
print(sum(t))  # imprime la suma
print(len(t))  # imprime cantidad de elementos
