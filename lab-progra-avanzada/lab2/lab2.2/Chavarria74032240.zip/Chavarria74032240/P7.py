a, b = 3, 5   # asigna 3 y 5
a, b = b, a   # intercambia valores

print((a - b,))  # imprime tupla con resta
print((a - b))   # imprime número de la resta
