t = (1, 2, 3)  # tupla inicial

# t.append(4)  # error, tupla no permite agregar
# t.remove(0)  # error, tupla no permite quitar
# t[0] = 1     # error, tupla no permite cambiar

print("No se puede usar append, remove ni reasignar en tuplas")  
