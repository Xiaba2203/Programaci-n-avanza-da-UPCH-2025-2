mi_tupla = (3, 8, 15, [2, 9], 23)  # tupla con lista
mi_tupla[3][1] = 5                 # cambia valor dentro de la lista

print(mi_tupla)  # imprime tupla modificada
