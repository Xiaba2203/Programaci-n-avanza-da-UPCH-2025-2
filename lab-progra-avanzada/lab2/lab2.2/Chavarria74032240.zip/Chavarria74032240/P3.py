t = (1, 2, 3, 7, 9, 0, 5)   # tupla ejemplo

print(t)         # imprime toda la tupla
print(t[0])      # imprime primer elemento
print(t[1:3])    # imprime del índice 1 al 2
print(t[-1])     # imprime último elemento
print(t[:-1])    # imprime todo menos el último
print(t[1:-1])   # imprime desde 2do hasta penúltimo
