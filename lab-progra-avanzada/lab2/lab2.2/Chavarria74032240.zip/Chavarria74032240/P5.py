t1 = (1, 2, 3, 7, 9, 0, 5)   # tupla 1
t2 = (1, 3, 22, 7, 9, 0, 5)  # tupla 2

print(t1 == t2)  # compara igualdad
print(t1 != t2)  # compara diferencia
print(t1 > t2)   # compara mayor (lexicográfico)
print(t1 < t2)   # compara menor (lexicográfico)
