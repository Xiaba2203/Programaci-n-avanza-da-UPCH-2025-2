t1 = (1, 2, 3, 7, 9, 0, 5)  # tupla 1
t2 = (1, 2, 5)              # tupla 2

t1 = t2  # reasigna t1 a t2

print("t1 ahora es:", t1)  # imprime nueva tupla
